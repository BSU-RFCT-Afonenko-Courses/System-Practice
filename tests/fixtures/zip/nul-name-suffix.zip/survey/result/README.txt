Dataset: station observations
Current: morning.txt, evening.txt
Archive: station.txt
